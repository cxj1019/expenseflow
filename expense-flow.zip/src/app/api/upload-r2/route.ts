//src\app\api\upload-r2\route.ts


import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { NextResponse } from 'next/server';
import crypto from 'crypto';

// 从环境变量中获取配置
const R2_ACCOUNT_ID = process.env.R2_ACCOUNT_ID;
const R2_ACCESS_KEY_ID = process.env.R2_ACCESS_KEY_ID;
const R2_SECRET_ACCESS_KEY = process.env.R2_SECRET_ACCESS_KEY;
const R2_BUCKET_NAME = process.env.R2_BUCKET_NAME;
const R2_PUBLIC_URL = process.env.R2_PUBLIC_URL;

// 【新增】在服务器启动时打印环境变量状态，方便调试
console.log("--- API Route: upload-r2 Initializing ---");
console.log("R2_ACCOUNT_ID:", R2_ACCOUNT_ID ? "Loaded" : "MISSING!");
console.log("R2_ACCESS_KEY_ID:", R2_ACCESS_KEY_ID ? "Loaded" : "MISSING!");
console.log("R2_SECRET_ACCESS_KEY:", R2_SECRET_ACCESS_KEY ? "Loaded" : "MISSING!");
console.log("R2_BUCKET_NAME:", R2_BUCKET_NAME ? "Loaded" : "MISSING!");
console.log("R2_PUBLIC_URL:", R2_PUBLIC_URL ? "Loaded" : "MISSING!");
console.log("-----------------------------------------");

// 增加启动时检查，确保所有环境变量都存在
if (!R2_ACCOUNT_ID || !R2_ACCESS_KEY_ID || !R2_SECRET_ACCESS_KEY || !R2_BUCKET_NAME || !R2_PUBLIC_URL) {
  // 这个错误只会在服务器的控制台（Vercel Logs 或你的本地终端）中看到
  console.error("FATAL: Cloudflare R2 环境变量缺失! 请检查你的 .env.local 文件或 Vercel/Netlify 上的环境变量设置。");
  if (process.env.NODE_ENV !== 'production') {
    throw new Error('缺少 Cloudflare R2 的环境变量，请检查 .env.local 文件');
  }
}

let s3Client: S3Client;
try {
  s3Client = new S3Client({
    region: 'auto',
    endpoint: `https://${R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: R2_ACCESS_KEY_ID!,
      secretAccessKey: R2_SECRET_ACCESS_KEY!,
    },
  });
  console.log("S3 Client initialized successfully.");
} catch (error) {
  console.error("FATAL: Failed to initialize S3 Client:", error);
}


const generateFileName = (bytes = 32) => crypto.randomBytes(bytes).toString('hex');

export async function POST(request: Request) {
  console.log("Received a request to generate pre-signed URL...");

  if (!s3Client) {
    console.error("S3 Client is not initialized. Cannot process request.");
    return NextResponse.json({ error: '服务器配置错误：无法连接到存储服务。' }, { status: 500 });
  }

  try {
    const body = await request.json();
    const { fileType, userId } = body;
    console.log(`Request body parsed: fileType=${fileType}, userId=${userId}`);

    if (!fileType || typeof fileType !== 'string' || !userId || typeof userId !== 'string') {
      console.error("Invalid request body. Missing or incorrect fileType/userId.");
      return NextResponse.json({ error: '文件类型 (fileType) 和用户ID (userId) 是必需的，且必须为字符串。' }, { status: 400 });
    }

    const fileExtension = fileType.split('/')[1];
    if (!fileExtension) {
      console.error("Could not determine file extension from fileType:", fileType);
      return NextResponse.json({ error: '无效的文件类型 (fileType)，无法解析文件扩展名。' }, { status: 400 });
    }

    const fileName = `${userId}/${generateFileName()}.${fileExtension}`;
    console.log(`Generated file name: ${fileName}`);

    const command = new PutObjectCommand({
      Bucket: R2_BUCKET_NAME,
      Key: fileName,
      ContentType: fileType,
    });

    console.log("Generating pre-signed URL...");
    const signedUrl = await getSignedUrl(s3Client, command, { expiresIn: 600 });
    console.log("Pre-signed URL generated successfully.");

    return NextResponse.json({ 
      uploadUrl: signedUrl, 
      accessUrl: `${R2_PUBLIC_URL}/${fileName}`
    });

  } catch (error: unknown) {
    console.error('An error occurred in POST /api/upload-r2:', error);
    if (error instanceof Error) {
      return NextResponse.json({ error: `服务器内部错误: ${error.message}` }, { status: 500 });
    } else {
      return NextResponse.json({ error: '服务器发生未知错误' }, { status: 500 });
    }
  }
}
